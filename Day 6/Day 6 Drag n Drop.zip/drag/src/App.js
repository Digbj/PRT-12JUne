// import logo from './logo.svg';
import './App.css';
import File from './component/drag';


function App() {
  return (
    <div className="App">
      <File/>
    </div>
  );
}

export default App;
