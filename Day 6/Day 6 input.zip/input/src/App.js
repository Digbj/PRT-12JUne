// import logo from './logo.svg';
import './App.css';
import Hello from './components/hello';

function App() {
  return (
    <div className="App">
  <Hello/>
    </div>
  );
}

export default App;
